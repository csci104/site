# CS104 HW1 Test Suite

## Running Testcases for Students
1. Copy this directory into your `hw1` folder
2. Open a terminal and cd into `hw1_tests`
3. Initialize the test suite by running `cmake .`
4. Compile the tests by typing `make`
5. Run the tests with `ctest`

Refer to this [page](https://bytes.usc.edu/cs104/wiki/cmake-tests) for additional information

## Running Testcases for Graders 
1. Copy this directory into your `hw1` folder
2. Open a terminal and cd into `hw1_tests`
3. Initialize the test suite by running `cmake .`
4. Run the tests by typing `make grade`.  To run the tests again, you only need to execute this command, not any others.

### Grade Output
Running `make grade` will generate a couple of outputs:
1. In the root directory: A formatted Markdown grade report, ready for submission to GitHub
2. In the `compile-logs` directory: Logs of the compilation output for each problem
3. In the `results` directory: Files listing the results of each test in a standard format, for input to other grading systems
4. In the `test-output` directory: Files containing the output each test printed.  To figure out why a test failed, start here!

# CS104 HW3 Heap Checker

### Using the Tests
1. Copy this directory into your `hw3` folder
2. Open a docker shell and cd into `hw3_heap_checker`
3. Initialize the test suite by running `cmake .`
4. Build the code by running `make`
5. Run the tests by typing `ctest` or `ctest --output-on-failure`.  To run the tests again, you only need to `make` again anytime you change your code and then rerun this `ctest` command.

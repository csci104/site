#include <fstream>
#include <gtest/gtest.h>
#include <user_code_runner.h>
#include <iostream>


void evaluateDoublet(const std::string& startWord, const std::string& endWord, const std::string& wordsFile, const std::string& expectedSteps, const std::string& expectedExpansions)
{
    std::string testCategory = testing::UnitTest::GetInstance()->current_test_info()->test_suite_name();
    std::string testName = testing::UnitTest::GetInstance()->current_test_info()->name();

    // Run the student's program
    std::string workingDirectory = TEST_BINARY_DIR "/doublet_tests/test_output/";
    std::string executablePath = DOUBLET_EXECUTABLE; // set by CMake
    std::string outputFilePath = TEST_BINARY_DIR "/doublet_tests/test_output/" + testName + ".txt";
    bool useValgrind = testCategory != "DoubletStress";

    std::string wordsFilePath = TEST_BINARY_DIR "/doublet_tests/words/" + wordsFile;
    std::vector<std::string> args {startWord, endWord, wordsFilePath};

    UserCodeRunner runner {workingDirectory, executablePath, args, outputFilePath, useValgrind};
    runner.setCheckExitCode(false);
    ASSERT_TRUE(runner.execute());

    std::ifstream outputFileStream {outputFilePath};
    ASSERT_TRUE(outputFileStream) << "Couldn't open output file (" << outputFilePath << ")";

    // Parse the output
    std::vector<std::string> outputLines;
    std::string line;
    while(std::getline(outputFileStream, line)) {
        if(!line.empty()) {
            outputLines.push_back(line);
        }
    }
    ASSERT_FALSE(outputLines.empty()) <<  "Output file is empty! Was there an issue with the arguments to doublet?";
    ASSERT_EQ(outputLines.size(), 2) << "Incorrect number of lines in output";

    // Check against expected
    EXPECT_EQ(outputLines[0], expectedSteps);
    EXPECT_EQ(outputLines[1], expectedExpansions);
}


TEST(Doublet, Test0_AAAAA_BBBBB)
{
    std::string startWord = "AAAAA";
    std::string endWord = "BBBBB";
    std::string wordFile = "words0.txt";
     
    std::string expectedSteps = "5";
    std::string expectedExpansions = "8";

    evaluateDoublet(startWord, endWord, wordFile, expectedSteps, expectedExpansions);
}

TEST(Doublet, Test1_leet_leak)
{
    std::string startWord = "leet";
    std::string endWord = "leak";
    std::string wordFile = "words1.txt";
     
    std::string expectedSteps = "No transformation";
    std::string expectedExpansions = "1";

    evaluateDoublet(startWord, endWord, wordFile, expectedSteps, expectedExpansions);
}

TEST(Doublet, Test2_leet_leek)
{
    std::string startWord = "leet";
    std::string endWord = "leek";
    std::string wordFile = "words2.txt";
     
    std::string expectedSteps = "1";
    std::string expectedExpansions = "1";

    evaluateDoublet(startWord, endWord, wordFile, expectedSteps, expectedExpansions);
}

TEST(Doublet, Test3_head_tail)
{
    std::string startWord = "head";
    std::string endWord = "tail";
    std::string wordFile = "words3.txt";
     
    std::string expectedSteps = "5";
    std::string expectedExpansions = "5";

    evaluateDoublet(startWord, endWord, wordFile, expectedSteps, expectedExpansions);
}

TEST(Doublet, Test4_leet_lean)
{
    std::string startWord = "leet";
    std::string endWord = "lean";
    std::string wordFile = "words4.txt";
     
    std::string expectedSteps = "3";
    std::string expectedExpansions = "3";

    evaluateDoublet(startWord, endWord, wordFile, expectedSteps, expectedExpansions);
}

TEST(Doublet, Test5_leet_keep)
{
    std::string startWord = "leet";
    std::string endWord = "keep";
    std::string wordFile = "words5.txt";
     
    std::string expectedSteps = "No transformation";
    std::string expectedExpansions = "6";

    evaluateDoublet(startWord, endWord, wordFile, expectedSteps, expectedExpansions);
}

TEST(Doublet, Test6_leet_mead)
{
    std::string startWord = "leet";
    std::string endWord = "mead";
    std::string wordFile = "words6.txt";
     
    std::string expectedSteps = "5";
    std::string expectedExpansions = "7";

    evaluateDoublet(startWord, endWord, wordFile, expectedSteps, expectedExpansions);
}

TEST(Doublet, Test7_leet_mead)
{
    std::string startWord = "leet";
    std::string endWord = "mead";
    std::string wordFile = "words7.txt";
     
    std::string expectedSteps = "4";
    std::string expectedExpansions = "6";

    evaluateDoublet(startWord, endWord, wordFile, expectedSteps, expectedExpansions);
}

TEST(Doublet, Test8_leet_mead)
{
    std::string startWord = "leet";
    std::string endWord = "mead";
    std::string wordFile = "words8.txt";
     
    std::string expectedSteps = "No transformation";
    std::string expectedExpansions = "6";

    evaluateDoublet(startWord, endWord, wordFile, expectedSteps, expectedExpansions);
}

TEST(Doublet, Test9_AAAA_BBBB)
{
    std::string startWord = "AAAA";
    std::string endWord = "BBBB";
    std::string wordFile = "words9.txt";
     
    std::string expectedSteps = "4";
    std::string expectedExpansions = "4";

    evaluateDoublet(startWord, endWord, wordFile, expectedSteps, expectedExpansions);
}

TEST(Doublet, Test10_AAAA_BBBB)
{
    std::string startWord = "AAAA";
    std::string endWord = "BBBB";
    std::string wordFile = "words10.txt";
     
    std::string expectedSteps = "No transformation";
    std::string expectedExpansions = "11";

    evaluateDoublet(startWord, endWord, wordFile, expectedSteps, expectedExpansions);
}

TEST(Doublet, Test11_ape_man)
{
    std::string startWord = "ape";
    std::string endWord = "man";
    std::string wordFile = "words11.txt";
     
    std::string expectedSteps = "5";
    std::string expectedExpansions = "5";

    evaluateDoublet(startWord, endWord, wordFile, expectedSteps, expectedExpansions);
}

TEST(Doublet, Test12_flour_bread)
{
    std::string startWord = "flour";
    std::string endWord = "bread";
    std::string wordFile = "words12.txt";
     
    std::string expectedSteps = "6";
    std::string expectedExpansions = "6";

    evaluateDoublet(startWord, endWord, wordFile, expectedSteps, expectedExpansions);
}

TEST(Doublet, Test13_one_two)
{
    std::string startWord = "one";
    std::string endWord = "two";
    std::string wordFile = "words13.txt";
     
    std::string expectedSteps = "7";
    std::string expectedExpansions = "8";

    evaluateDoublet(startWord, endWord, wordFile, expectedSteps, expectedExpansions);
}

TEST(Doublet, Test14_river_gotee)
{
    std::string startWord = "river";
    std::string endWord = "gotee";
    std::string wordFile = "words14.txt";
     
    std::string expectedSteps = "6";
    std::string expectedExpansions = "14";

    evaluateDoublet(startWord, endWord, wordFile, expectedSteps, expectedExpansions);
}

TEST(Doublet, Test15_black_white)
{
    std::string startWord = "black";
    std::string endWord = "white";
    std::string wordFile = "words15.txt";
     
    std::string expectedSteps = "7";
    std::string expectedExpansions = "7";

    evaluateDoublet(startWord, endWord, wordFile, expectedSteps, expectedExpansions);
}

TEST(Doublet, Test16_blue_pink)
{
    std::string startWord = "blue";
    std::string endWord = "pink";
    std::string wordFile = "words16.txt";
     
    std::string expectedSteps = "9";
    std::string expectedExpansions = "12";

    evaluateDoublet(startWord, endWord, wordFile, expectedSteps, expectedExpansions);
}

TEST(Doublet, Test17_river_shore)
{
    std::string startWord = "river";
    std::string endWord = "shore";
    std::string wordFile = "words17.txt";
     
    std::string expectedSteps = "11";
    std::string expectedExpansions = "18";

    evaluateDoublet(startWord, endWord, wordFile, expectedSteps, expectedExpansions);
}

TEST(Doublet, Test18_witch_fairy)
{
    std::string startWord = "witch";
    std::string endWord = "fairy";
    std::string wordFile = "words18.txt";
     
    std::string expectedSteps = "13";
    std::string expectedExpansions = "27";

    evaluateDoublet(startWord, endWord, wordFile, expectedSteps, expectedExpansions);
}

TEST(Doublet, Test19_sleep_dream)
{
    std::string startWord = "sleep";
    std::string endWord = "dream";
    std::string wordFile = "words19.txt";
     
    std::string expectedSteps = "No transformation";
    std::string expectedExpansions = "9";

    evaluateDoublet(startWord, endWord, wordFile, expectedSteps, expectedExpansions);
}

TEST(DoubletStress, Test20_AAAAAAAAAA_ZZZZZZZZZZ)
{
    std::string startWord = "AAAAAAAAAA";
    std::string endWord = "ZZZZZZZZZZ";
    std::string wordFile = "words20.txt";
     
    std::string expectedSteps = "250";
    std::string expectedExpansions = "93970";

    evaluateDoublet(startWord, endWord, wordFile, expectedSteps, expectedExpansions);
}

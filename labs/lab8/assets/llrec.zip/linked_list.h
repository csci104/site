#ifndef LINKED_LIST_LINKED_LIST_H
#define LINKED_LIST_LINKED_LIST_H

#include <vector>

struct Node {
    int val = -999;
    Node* next = nullptr;
};

Node* from_vector(const std::vector<int>& values);

std::vector<int> to_vector(Node* node);

int ll_len(Node* head);

void ll_unique(Node* node);

void ll_partial_sum(Node* head);

Node* ll_rotate(Node* head, int n);

int ll_compare(Node* lhs, Node* rhs);

#endif //LINKED_LIST_LINKED_LIST_H

#include "linked_list.h"
#include <stdexcept>

Node *from_vector(const std::vector<int> &values) {
    Node *head = nullptr;
    Node **p_insert = &head;

    for (int v: values) {
        Node *node = new Node;
        node->val = v;
        *p_insert = node;
        p_insert = &node->next;
    }

    return head;
}

std::vector<int> to_vector(Node *node) {

    constexpr static int threshold = 1024;

    std::vector<int> vec;
    size_t iter_cnt = 0;
    while (node) {
        vec.push_back(node->val);
        node = node->next;
        if (++iter_cnt > threshold) {
            throw std::out_of_range("There might be a cycle in your linked list");
        }
    }
    return vec;
}

int ll_len(Node *head) {
    return head ? ll_len(head->next) + 1 : 0;
}

void ll_unique(Node *node) {
    if (!node || !node->next) {
        return;
    }
    if (node->val == node->next->val) {
        Node *n_next = node->next->next;
        delete node->next;
        node->next = n_next;
        ll_unique(node);
    } else {
        ll_unique(node->next);
    }
}

void ll_partial_sum(Node *head) {
    if (!head || !head->next) {
        return;
    }
    head->next->val += head->val;
    ll_partial_sum(head->next);
}

Node *ll_tail(Node *head) {
    return head->next ? ll_tail(head->next) : head;
}

Node *ll_rotate_with_tail(Node *head, Node *tail, int n) {
    if (n <= 0) {
        return head;
    }
    Node *n_head = head->next;
    head->next = nullptr;
    tail->next = head;
    return ll_rotate_with_tail(n_head, head, n - 1);
}

Node *ll_rotate(Node *head, int n) {
    if (!head || !head->next) {
        return head;
    }
    return ll_rotate_with_tail(head, ll_tail(head), n);
}

int ll_compare(Node *lhs, Node *rhs) {
    if (!lhs && !rhs) {
        return 0;
    }
    if (!lhs) {
        return -1;
    }
    if (!rhs) {
        return 1;
    }
    int l_val = lhs->val;
    int r_val = rhs->val;
    if (l_val > r_val) {
        return 1;
    }
    if (r_val > l_val) {
        return -1;
    }
    return ll_compare(lhs->next, rhs->next);
}

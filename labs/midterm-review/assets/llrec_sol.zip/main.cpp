#include "linked_list.h"

#include <iostream>
#include <vector>

std::ostream &operator<<(std::ostream &os, const std::vector<int> &vec) {
    os << "[ ";
    for (int x: vec) {
        os << x << " ";
    }
    os << "]";
    return os;
}

int main() {
    Node *list = from_vector({1, 1, 2, 3, 4, 4, 5, 5, 5, 4, 5, 6});
    ll_unique(list);
    std::cout << to_vector(list) << std::endl;
    list = ll_rotate(list, 2);
    std::cout << to_vector(list) << std::endl;
    ll_partial_sum(list);
    std::cout << to_vector(list) << std::endl;

    std::cout << ll_compare(list, list) << std::endl;

    std::cout << ll_compare(
            from_vector({1, 2, 3, 4}),
            from_vector({1, 2, 4})
    ) << std::endl;

    std::vector<int> a;
    std::vector<int> b;

    return 0;
}
